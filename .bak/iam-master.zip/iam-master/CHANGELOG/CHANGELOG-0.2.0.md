
<a name="v0.2.0"></a>
## [v0.2.0](https://github.com/marmotedu/iam/compare/v0.1.2...v0.2.0) (2020-10-21)

### Bug Fixes

* **pkg:** panic when start HTTP/GRPC server failed
* **pkg:** fix the wrong ping path

### Code Refactoring

* **apiserver:** change gorm logger
* **pkg:** add dump middleware
* **pkg:** add custom logger middleware

### Features

* **apiserver:** change gorm v1 to v2

