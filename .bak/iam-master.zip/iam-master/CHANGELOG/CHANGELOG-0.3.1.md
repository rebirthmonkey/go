
<a name="v0.3.1"></a>
## [v0.3.1](https://github.com/marmotedu/iam/compare/v0.3.0...v0.3.1) (2020-12-18)

### Bug Fixes

* fix compile error

