
<a name="v1.0.2"></a>
## [v1.0.2](https://github.com/marmotedu/iam/compare/v1.0.1...v1.0.2) (2021-07-08)

### Bug Fixes

* add missing `controller` directory

