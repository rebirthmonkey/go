
<a name="v1.0.4"></a>
## [v1.0.4](https://github.com/marmotedu/iam/compare/v1.0.3...v1.0.4) (2021-07-08)

### Code Refactoring

* change Handler to Controller, remove store from Controller
* **authzserver:** change api and handler to controller

