# Contributing

Welcome to Marmotedu! If you are interested in contributing to the [Marmotedu code repo](README.md) then checkout the [Contributor's Guide](https://github.com/marmotedu/community/blob/master/CONTRIBUTING.md)

The [Marmotedu community repo](https://github.com/marmotedu/community) contains information on how the community is organized and other information that is pertinent to contributing.
