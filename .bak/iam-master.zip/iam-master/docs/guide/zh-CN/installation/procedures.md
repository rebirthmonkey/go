# 安装步骤

[部署架构](./architecture.md)

## 1. 需求检查 & 依赖安装

请参考：[需求检查](./requirement.md)

## 2. 代码包下载

```bash
git clone https://github.com/marmotedu/iam
```

## 3. 编译

```bash
cd iam
make
```
