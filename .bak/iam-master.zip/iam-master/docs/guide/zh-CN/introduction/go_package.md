# IAM 项目推荐使用的 Go 包
- 参数校验：github.com/asaskevich/govalidator
